import React from 'react'
import { Link } from 'react-router-dom'
import { routes } from '../Router/routes'
import "../styles/Navbar.css";
import {useDoctorState} from "../Context/global.context";

const Navbar = () => {
  const defaultDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const {dispatch, state} = useDoctorState();
  const initialState = { isLightTheme: true };
  

  return (
    <nav className="navbar">
      <Link to={routes.home}>
      <h4>Home</h4>
      </Link>
      <Link to={routes.contact}>
      <h4>Contact</h4>
      </Link>
      <Link to={routes.favs}>
      <h4>Favs</h4>
      </Link>
      {/* Aqui deberan agregar los liks correspondientes a las rutas definidas */}
      {/* Deberan implementar ademas la logica para cambiar de Theme con el button */}
      <button onClick={() => dispatch({ type: "THEME" })}>
      {state.isLightTheme ? "Cambiar a Oscuro" : "Cambiar a Claro"}Change theme</button>
    </nav>
  )
}

export default Navbar